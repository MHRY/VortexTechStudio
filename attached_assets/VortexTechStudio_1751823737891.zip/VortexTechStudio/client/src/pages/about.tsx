import AboutContent from "@/components/sections/about-content";

const About = () => {
  return (
    <div className="pt-16">
      <AboutContent />
    </div>
  );
};

export default About;
