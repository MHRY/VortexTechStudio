import ContactForm from "@/components/sections/contact-form";

const Contact = () => {
  return (
    <div className="pt-16">
      <ContactForm />
    </div>
  );
};

export default Contact;
