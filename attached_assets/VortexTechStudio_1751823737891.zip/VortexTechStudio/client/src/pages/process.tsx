import ProcessTimeline from "@/components/sections/process-timeline";

const Process = () => {
  return (
    <div className="pt-16">
      <ProcessTimeline />
    </div>
  );
};

export default Process;
