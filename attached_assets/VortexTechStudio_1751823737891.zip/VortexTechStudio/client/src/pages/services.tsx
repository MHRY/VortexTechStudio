import ServicesDetail from "@/components/sections/services-detail";

const Services = () => {
  return (
    <div className="pt-16">
      <ServicesDetail />
    </div>
  );
};

export default Services;
